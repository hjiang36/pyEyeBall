PyEyeBall is a python toolbox designed for simulating the front end properties of                       human visual system. The goal of pyEyeBall is the same as ISETBIO toolbox in Matlab,                       with code structure redesigned.


